import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { MeetupLobbyPage } from './meetup-lobby.page';

const routes: Routes = [
  {
    path: '',
    component: MeetupLobbyPage
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class MeetupLobbyPageRoutingModule {}
