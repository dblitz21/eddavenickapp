import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'meetup-lobby',
  templateUrl: './meetup-lobby.page.html',
  styleUrls: ['./meetup-lobby.page.scss'],
})
export class MeetupLobbyPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
