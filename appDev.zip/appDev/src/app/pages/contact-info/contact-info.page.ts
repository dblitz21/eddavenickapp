import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'contact-info',
  templateUrl: './contact-info.page.html',
  styleUrls: ['./contact-info.page.scss'],
})
export class ContactInfoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
